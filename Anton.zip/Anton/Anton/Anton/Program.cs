﻿using System;

namespace HelloApp
{
    class Program
    {
        static void Main(string[] args)
        {
            //            string str = "+---+\n|   |\n|   |\n|   |\n+---+";
            //            Console.WriteLine(str);
            //            Console.WriteLine();

            //            string strI = "+---+\n  +  \n  +\n|   |\n+---+";
            //            Console.WriteLine(strI);
            //            Console.WriteLine();


            //            string strT = "+---+\n  +  \n  +\n  +  \n  +\n \n";
            //            Console.WriteLine(strT);
            //            Console.WriteLine();


            //            string strE = "|----\n|    \n|----  \n|    \n|----  \n \n";
            //            Console.WriteLine(strE);
            //            Console.WriteLine();



            //            string strM = "|\\__/| \n|    |\n|    |\n  \n \n";
            //            Console.WriteLine(strM);
            //            Console.WriteLine();



            //            string strA = "   +    \n  +   \n +  \n+      +                  "; 
            //            Console.WriteLine(strA);
            //            Console.WriteLine();




















            //            Console.WriteLine("Таблица умножения");
            //            for (int i = 1; i < 16; ++i)
            //            {
            //                for (int j = 1; j < 16; j++)
            //                {
            //                    Console.Write($"{i * j,-3} ");
            //                }
            //                Console.WriteLine();
            //            }



            //        }
            //    }
            //}



            //            int value = 0;
            //            int num = 0;
            //            string input_string = "";
            //            int i = 0;
            //            bool run = true;

            //            Console.WriteLine("<<< Guess my namber / Угадай число>>>");
            //            Console.WriteLine("I choose number - you guees! я загадал число - а ты отгадай!");



            //            while (run)
            //            {
            //                Random rnd = new Random();
            //                value = rnd.Next(0, 20);


            //                Console.WriteLine("I chosse number form 0 to 20, Your turn! / Я загадал число от 0 до 20. Твой ход ");
            //                Console.WriteLine("Print number: / напиши число: ");


            //                for (i = 0; i < 10 && num != value; i++)
            //                {
            //                    Console.WriteLine("turn / ход #" + i);
            //                    input_string = Console.ReadLine();



            //                    num = Int32.Parse(input_string);

            //                    if (value != num)
            //                    {
            //                        Console.WriteLine("You Wrong! / неправильно");
            //                        if (num > value)
            //                        {
            //                            Console.WriteLine("Less / Меньше");
            //                        }
            //                        else
            //                        {
            //                            Console.WriteLine("More / Больше");
            //                        }
            //                    }
            //                }
            //                if (num == value)
            //                {
            //                    Console.WriteLine("You Win / Победа");
            //                }
            //                else
            //                {
            //                    Console.WriteLine("YOU LOOSE / Проигрыш");
            //                }
            //                Console.WriteLine("Do you want to continue? / Хочешь ещё поиграть ? Нажми y/n");
            //                while (input_string != "y" & input_string != "n")
            //                {
            //                    input_string = Console.ReadLine();
            //                    if (input_string == "y")
            //                    { }
            //                    else
            //                    {
            //                        if (input_string == "n")
            //                        {
            //                            run = false;
            //                        }
            //                        else
            //                        {
            //                            Console.WriteLine("не понял, введите ответ");

            //                        }
            //                    }
            //                }
            //            }
            //        }
            //    }
            //}










            //string name = "Anton";
            //int age = 11;
            //bool isEmployed = false;
            //double weight = 52;
            //bool playgamesPС = true;
            //string scool = "№ 204 г. Минска";
            //double pizza = 0.25;








            //Console.WriteLine($"Имя: {name}");
            //Console.WriteLine($"Возраст: {age}");
            //Console.WriteLine($"Вес: {weight}");
            //Console.WriteLine($"Работает: {isEmployed}");
            //Console.WriteLine($"Играешь или нет в ПК игры : {playgamesPС}");
            //Console.WriteLine($"Полное назввние школы: {scool}");
            //Console.WriteLine($"число компьютеров в компютерном классе: {25}");
            //Console.WriteLine($"Какая часть пицы достанется каждому если её делят на 4 человека: {pizza}");




            //Console.ReadLine();





            Console.Write("Введите имя: ");
            string name = Console.ReadLine();

            Console.Write("Введите возраст: ");
            int age = Convert.ToInt32(Console.ReadLine());

            Console.Write("Введите рост: ");
            double height = Convert.ToDouble(Console.ReadLine());

            Console.Write("Введите размер зарплаты: ");
            decimal salary = Convert.ToDecimal(Console.ReadLine());

            Console.Write("Введите отчество: ");
            string o = (Console.ReadLine());

            Console.Write("Количество этажей в школе: ");
            int f = Convert.ToInt32(Console.ReadLine());

            Console.Write("Какая часть торта достанется каждому если его делят на 5 человек: ");
            double r = Convert.ToDouble(Console.ReadLine());

            long number = 375293608993;
            Console.WriteLine($" telefon {number: +### ## ### ## ##}"); 


            Console.WriteLine($"Имя: {name} Возраст: {age} Рост: {height} Зарплата: {salary}$ отчество: {o} Количество этажей в школе: {f} часть торта на 5 человек:{r} number: {number: +### ## ### ## ##}") ;



              














         //   Console.ReadLine();

        }
    }
}





















